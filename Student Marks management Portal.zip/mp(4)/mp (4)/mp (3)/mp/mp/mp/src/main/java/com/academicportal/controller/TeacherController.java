package com.academicportal.controller;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.academicportal.model.Teacher;
import com.academicportal.model.ClassRoom;
import com.academicportal.service.TeacherService;
import com.academicportal.repository.ClassRoomRepository;
import com.academicportal.repository.StudentRepository;
import com.academicportal.model.Student;
import com.academicportal.model.Marksheet;
import com.academicportal.repository.MarksheetRepository;

@RestController
@RequestMapping("/api/teacher")
public class TeacherController {
    
    private static final Logger logger = LoggerFactory.getLogger(TeacherController.class);
    
    @Autowired
    private TeacherService teacherService;

    @Autowired
    private ClassRoomRepository classRoomRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private MarksheetRepository marksheetRepository;

    @GetMapping("/profile/{emailId:.+}")
    public ResponseEntity<Teacher> getTeacherProfile(@PathVariable String emailId) {
        logger.info("Received request for teacher profile with email: {}", emailId);
        Teacher teacher = teacherService.getTeacherByEmail(emailId);
        if (teacher == null) {
            logger.error("Teacher not found for email: {}", emailId);
            return ResponseEntity.notFound().build();
        }
        logger.info("Found teacher profile with ID: {}", teacher.getTeacherId());
        return ResponseEntity.ok(teacher);
    }

    @GetMapping("/classes/{teacherId}")
    public ResponseEntity<List<ClassRoom>> getTeacherClasses(@PathVariable String teacherId) {
        if (teacherId == null || teacherId.equals("undefined")) {
            logger.error("Invalid teacher ID received: {}", teacherId);
            return ResponseEntity.badRequest().build();
        }
        
        logger.info("Fetching classes for teacher ID: {}", teacherId);
        List<ClassRoom> classes = teacherService.getTeacherClasses(teacherId);
        logger.info("Raw classes result: {}", classes);
        
        if (classes.isEmpty()) {
            logger.warn("No classes found for teacher ID: {}", teacherId);
        } else {
            logger.info("Found {} classes for teacher ID: {}", classes.size(), teacherId);
        }
        
        return ResponseEntity.ok(classes);
    }

    @GetMapping("/students")
    public ResponseEntity<List<Student>> getStudentsByIds(@RequestParam("ids") List<String> ids) {
        List<Student> students = studentRepository.findBy_idIn(ids);
        return ResponseEntity.ok(students);
    }

    @PostMapping("/marksheets")
    public ResponseEntity<Marksheet> saveMarksheet(@RequestBody Marksheet marksheet) {
        Marksheet saved = marksheetRepository.save(marksheet);
        return ResponseEntity.ok(saved);
    }
    @GetMapping("/marksheets")
    public List<Marksheet> getAllMarksheets() {
        return marksheetRepository.findAll();
    }
    @DeleteMapping("/marksheets/{id}")
    public ResponseEntity<Void> deleteMarksheet(@PathVariable String id) {
        marksheetRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/marksheets/{id}")
    public ResponseEntity<Marksheet> getMarksheet(@PathVariable String id) {
        return marksheetRepository.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/marksheets/{id}")
    public ResponseEntity<Marksheet> updateMarksheet(@PathVariable String id, @RequestBody Marksheet updated) {
        return marksheetRepository.findById(id)
            .map(existing -> {
                updated.setId(id);
                Marksheet saved = marksheetRepository.save(updated);
                return ResponseEntity.ok(saved);
            })
            .orElse(ResponseEntity.notFound().build());
    }
}