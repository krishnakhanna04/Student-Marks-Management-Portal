package com.academicportal.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.academicportal.model.Admin;

@Repository
public interface AdminRepository extends MongoRepository<Admin, String> {
    @Query("{ 'emailId' : ?0 }")
    Admin findByEmailId(String emailId);
}