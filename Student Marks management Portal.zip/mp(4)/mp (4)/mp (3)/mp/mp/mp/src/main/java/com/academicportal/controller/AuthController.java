package com.academicportal.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.academicportal.model.Admin;
import com.academicportal.model.Teacher;
import com.academicportal.repository.AdminRepository;
import com.academicportal.repository.StudentRepository;
import com.academicportal.repository.TeacherRepository;
import com.academicportal.service.AuthService;

@RestController
@RequestMapping("/api")
public class AuthController {
    
    @Autowired
    private AuthService authService;

    @Autowired
    private TeacherRepository teacherRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private AdminRepository adminRepository;

    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

    @PostMapping("/request-otp")
    public ResponseEntity<?> requestOTP(@RequestBody Map<String, String> request) {
        try {
            String email = request.get("email");
            if (email == null || email.trim().isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("error", "Email is required"));
            }

            logger.info("Requesting OTP for email: {}", email);
            String otp = authService.generateAndSendOTP(email);
            
            return ResponseEntity.ok(Map.of(
                "message", "OTP sent successfully",
                "email", email
            ));
        } catch (Exception e) {
            logger.error("Error generating OTP: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().body(Map.of(
                "error", "Failed to generate OTP"
            ));
        }
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<?> verifyOTP(@RequestBody Map<String, String> request) {
        try {
            String email = request.get("email");
            String otp = request.get("otp");
            Map<String, Object> response = authService.verifyOTP(email, otp);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/user-info")
    public ResponseEntity<?> getUserInfo(@RequestParam String email) {
        try {
            Map<String, Object> userInfo = authService.getUserInfo(email);
            return ResponseEntity.ok(userInfo);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/check-email")
    public ResponseEntity<?> checkEmail(@RequestParam String email) {
        try {
            logger.info("Checking email existence: {}", email);

            // Check teachers collection first
            Teacher teacher = teacherRepository.findByEmailid(email);
            if (teacher != null) {
                logger.info("Found teacher with email: {}", email);
                return ResponseEntity.ok().body(Map.of(
                    "exists", true,
                    "role", "teacher",
                    "teacherId", teacher.getTeacherId()
                ));
            }

            // Check admin collection
            Admin admin = adminRepository.findByEmailId(email);
            if (admin != null) {
                logger.info("Found admin with email: {}", email);
                return ResponseEntity.ok().body(Map.of(
                    "exists", true,
                    "role", "admin",
                    "adminId", admin.getAdminId()
                ));
            }

            logger.warn("Email not found: {}", email);
            return ResponseEntity.ok().body(Map.of(
                "exists", false,
                "message", "Email not found"
            ));
            
        } catch (Exception e) {
            logger.error("Error checking email: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().body(Map.of(
                "error", "Error verifying email"
            ));
        }
    }

    // Remove the duplicate endpoint
    // Delete the following method:
    // @GetMapping("/admin/admin/{emailId}")
    // public ResponseEntity<?> getAdminProfile(@PathVariable String emailId) { ... }
}