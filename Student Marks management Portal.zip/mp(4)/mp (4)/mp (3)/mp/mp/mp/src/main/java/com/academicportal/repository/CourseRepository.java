package com.academicportal.repository;

import com.academicportal.model.Course;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CourseRepository extends MongoRepository<Course, String> {
    Course findByCoursecode(String coursecode);
    Course findByCourseId(String courseId);
    void deleteByCourseId(String courseId);
}