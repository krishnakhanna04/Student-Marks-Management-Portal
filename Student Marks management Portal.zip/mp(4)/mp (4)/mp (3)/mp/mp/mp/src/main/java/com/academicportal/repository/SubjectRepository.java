package com.academicportal.repository;

import com.academicportal.model.Subject;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface SubjectRepository extends MongoRepository<Subject, String> {
    Subject findBySubjectId(String subjectId);
    void deleteBySubjectId(String subjectId);
}