package com.academicportal.model;

public class SubjectTeacher {
    private String subjectId;
    private String subjectName; // Add this field
    private Teacher teacher;

    // Add getters and setters
    public String getSubjectName() { return subjectName; }
    public void setSubjectName(String subjectName) { this.subjectName = subjectName; }

    // Getters
    public String getSubjectId() { return subjectId; }
    public String getSubject() { return subjectName; }
    public Teacher getTeacher() { return teacher; }

     //Setters
    public void setSubjectId(String subjectId) { this.subjectId = subjectId; }
    public void setSubject(String subjectName) { this.subjectName = subjectName; }
    public void setTeacher(Teacher teacher) { this.teacher = teacher; }
}

