package com.academicportal.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import com.academicportal.model.Teacher;

public interface TeacherRepository extends MongoRepository<Teacher, String> {
    @Query("{ 'emailid' : ?0 }")
    Teacher findByEmailid(String emailid);
}