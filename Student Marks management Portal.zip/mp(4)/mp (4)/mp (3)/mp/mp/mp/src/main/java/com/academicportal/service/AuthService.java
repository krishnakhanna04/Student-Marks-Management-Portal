package com.academicportal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Service
public class AuthService {
    
    @Autowired
    private MongoTemplate mongoTemplate;
    
    private Map<String, String> otpStore = new HashMap<>(); // In production, use Redis or similar

    public String generateAndSendOTP(String email) {
        // Check if email exists in admin or teachers collection
        if (!isValidUser(email)) {
            throw new RuntimeException("Email not found in our records");
        }

        // Generate 4-digit OTP
        String otp = String.format("%04d", new Random().nextInt(10000));
        otpStore.put(email, otp);

        // In production, implement actual email sending logic here
        // For now, just print the OTP
        System.out.println("OTP for " + email + ": " + otp);

        return otp;
    }

    public Map<String, Object> verifyOTP(String email, String otp) {
        String storedOTP = otpStore.get(email);
        if (storedOTP == null || !storedOTP.equals(otp)) {
            throw new RuntimeException("Invalid OTP");
        }

        // Remove used OTP
        otpStore.remove(email);

        // Get user info and role
        Map<String, Object> userInfo = getUserInfo(email);
        userInfo.put("success", true);
        
        return userInfo;
    }

    public Map<String, Object> getUserInfo(String email) {
        // Check admin collection
        Query adminQuery = new Query(Criteria.where("emailId").is(email));
        Map<String, Object> admin = mongoTemplate.findOne(adminQuery, Map.class, "admin");
        
        if (admin != null) {
            Map<String, Object> response = new HashMap<>();
            response.put("role", "admin");
            response.put("userId", admin.get("adminId"));
            response.put("name", admin.get("firstName") + " " + admin.get("lastName"));
            return response;
        }

        // Check teacher collection - Fixed field name to match your collection
        Query teacherQuery = new Query(Criteria.where("emailid").is(email)); // Changed from emailid to emailId
        Map<String, Object> teacher = mongoTemplate.findOne(teacherQuery, Map.class, "teachers");
        
        if (teacher != null) {
            Map<String, Object> response = new HashMap<>();
            response.put("role", "teacher");
            response.put("userId", teacher.get("teacherId"));
            response.put("name", teacher.get("firstName") + " " + teacher.get("lastName"));
            return response;
        }

        throw new RuntimeException("User not found");
    }

    private boolean isValidUser(String email) {
        // Check in admin collection
        Query adminQuery = new Query(Criteria.where("emailId").is(email));
        boolean isAdmin = mongoTemplate.exists(adminQuery, "admin");

        // Check in teachers collection - Fixed field name to match your collection
        Query teacherQuery = new Query(Criteria.where("emailid").is(email)); // Changed from emailid to emailId
        boolean isTeacher = mongoTemplate.exists(teacherQuery, "teachers");

        return isAdmin || isTeacher;
    }
}