package com.academicportal.controller;

import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.academicportal.service.OTPService;

@RestController
@RequestMapping("/api/otp")
public class OTPController {
    
    private static final Logger logger = LoggerFactory.getLogger(OTPController.class);
    
    @Autowired
    private OTPService otpService;
    
    @PostMapping("/request")
    public ResponseEntity<?> requestOTP(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        logger.debug("Received OTP request for email: {}", email);
        
        if (email == null || email.trim().isEmpty()) {
            return ResponseEntity.badRequest()
                .body(Map.of("error", "Email is required"));
        }
        
        try {
            boolean sent = otpService.generateAndSendOTP(email);
            if (sent) {
                logger.info("OTP sent successfully to: {}", email);
                return ResponseEntity.ok()
                    .body(Map.of("message", "OTP sent successfully"));
            } else {
                logger.error("Email not found: {}", email);
                return ResponseEntity.badRequest()
                    .body(Map.of("error", "Email not found in our records"));
            }
        } catch (Exception e) {
            logger.error("Error processing OTP request: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "Failed to send OTP. Please try again."));
        }
    }

    @PostMapping("/verify")
    public ResponseEntity<?> verifyOTP(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        String otp = request.get("otp");
        Map<String, String> response = otpService.verifyOTP(email, otp);
        
        if (response.containsKey("error")) {
            return ResponseEntity.badRequest().body(response);
        }

        String dashboardUrl = response.get("userType").equals("ADMIN") 
            ? "/admin-dashboard.html" 
            : "/teacher-dashboard.html";
        response.put("redirectUrl", dashboardUrl);
        
        return ResponseEntity.ok(response);
    }
}