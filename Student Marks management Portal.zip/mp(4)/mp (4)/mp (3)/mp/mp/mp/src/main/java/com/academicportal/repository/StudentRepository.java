package com.academicportal.repository;

import com.academicportal.model.Student;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import java.util.List;

public interface StudentRepository extends MongoRepository<Student, String> {
    @Query(value = "{ 'courseCode' : ?0 }")
    List<Student> findByCourseCode(String courseCode);
    List<Student> findBy_idIn(List<String> ids);
}