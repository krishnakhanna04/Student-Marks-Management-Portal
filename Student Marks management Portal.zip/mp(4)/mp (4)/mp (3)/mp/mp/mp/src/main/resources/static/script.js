document.addEventListener("DOMContentLoaded", () => {
    // Get DOM elements
    const emailInput = document.getElementById("emailAddress");
    const nextButton = document.querySelector(".nextButton");
    const step1 = document.querySelector(".step1");
    const step2 = document.querySelector(".step2");
    const step3 = document.querySelector(".step3");
    const verifyEmail = document.getElementById("verifyEmail");
    const otpInputs = document.querySelectorAll(".otp-input");
    const verifyButton = document.querySelector(".verifyButton");

    // Hide step2 initially
    if (step2) step2.style.display = "none";

    // Initialize state
    let currentEmail = '';

    // Email validation function
    function validateEmail(email) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailPattern.test(email);
    }

    // Add email input listener
    if (emailInput) {
        emailInput.addEventListener("input", (e) => {
            const isValid = validateEmail(e.target.value);
            if (nextButton) {
                nextButton.classList.toggle("disable", !isValid);
            }
        });
    }

    // Add next button click listener
    if (nextButton) {
        nextButton.addEventListener("click", async () => {
            const email = emailInput.value;
            if (!validateEmail(email)) {
                alert("Please enter a valid email address");
                return;
            }

            try {
                const response = await fetch("/api/otp/request", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({ email })
                });

                let data;
                try {
                    data = await response.json();
                } catch (e) {
                    console.error("Failed to parse JSON response:", e);
                    throw new Error("Server returned invalid response");
                }

                if (response.ok) {
                    currentEmail = email;
                    if (verifyEmail) verifyEmail.textContent = email;
                    if (step1) step1.style.display = "none";
                    if (step2) step2.style.display = "block";
                } else {
                    throw new Error(data.error || "Failed to send OTP");
                }
            } catch (error) {
                console.error("Error:", error);
                alert(error.message || "Server error. Please try again.");
            }
        });
    }

    // OTP input handling
    otpInputs.forEach((input, index) => {
        input.addEventListener("input", (e) => {
            const value = e.target.value;
            
            // Ensure only one digit
            if (value.length > 1) {
                input.value = value.slice(0, 1);
            }
            
            if (value.length === 1 && index < otpInputs.length - 1) {
                otpInputs[index + 1].focus();
            }
            
            // Check if all inputs are filled
            const isComplete = Array.from(otpInputs).every(input => input.value.length === 1);
            if (verifyButton) {
                verifyButton.classList.toggle("disable", !isComplete);
            }
        });

        input.addEventListener("keydown", (e) => {
            if (e.key === "Backspace" && !e.target.value && index > 0) {
                otpInputs[index - 1].focus();
            }
        });
    });

    // Check user authentication on load
    checkUserAuthentication();
});

// Global function for OTP verification
function verifyUser() {
    const otpInputs = document.querySelectorAll(".otp-input");
    const otp = Array.from(otpInputs).map(input => input.value).join("");
    const email = document.getElementById("verifyEmail").textContent;

    if (!email || !otp) {
        alert('Please enter the complete OTP');
        return;
    }

    fetch("/api/otp/verify", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ email, otp })
    })
    .then(response => {
        console.log('Raw response:', response);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log('Parsed response data:', data);

        if (!data || !data.userType) {
            throw new Error('Invalid response: missing user type');
        }

        if (data.error) {
            throw new Error(data.error);
        }

        // Show success message first
        document.querySelector(".step2").style.display = "none";
        document.querySelector(".step3").style.display = "block";

        // Store authentication data
        localStorage.setItem('userType', data.userType);
        localStorage.setItem('isAuthenticated', 'true');
        localStorage.setItem('userEmail', email);

        // Set verification flag
        sessionStorage.setItem('fromVerification', 'true');

        // Redirect based on user type
        const dashboardUrl = data.userType === 'ADMIN' ? 
            '/admin-dashboard.html' : 
            '/teacher-dashboard.html';
        
        setTimeout(() => {
            window.location.replace(dashboardUrl);
        }, 2000);
    })
    .catch(error => {
        console.error('Error:', error);
        alert(error.message || 'Verification failed');
        
        // Clear OTP inputs on error
        otpInputs.forEach(input => input.value = '');
        otpInputs[0].focus();
    });
}

// Add authentication check function
function checkUserAuthentication() {
    const userType = localStorage.getItem('userType');
    const isAuthenticated = localStorage.getItem('isAuthenticated');
    const currentPage = window.location.pathname.toLowerCase();
    const isRedirecting = sessionStorage.getItem('redirecting');
    
    // Clear redirect flag
    if (isRedirecting) {
        sessionStorage.removeItem('redirecting');
        return;
    }
    
    console.log('Current Auth State:', {
        userType,
        isAuthenticated,
        currentPage
    });
    
    // Skip checks for non-dashboard pages
    if (currentPage === '/' || 
        currentPage === '/index.html' || 
        currentPage.endsWith('.css') || 
        currentPage.endsWith('.js') || 
        currentPage.endsWith('.png')) {
        return;
    }
    
    // Check session timestamp
    const timestamp = localStorage.getItem('sessionTimestamp');
    const isSessionValid = timestamp && (Date.now() - parseInt(timestamp) < 3600000); // 1 hour

    if (!isSessionValid) {
        localStorage.clear();
        window.location.replace('/index.html');
        return;
    }
    
    // Dashboard access checks
    if (currentPage.includes('admin-dashboard')) {
        if (isAuthenticated === 'true' && userType === 'ADMIN') {
            return;
        }
    } else if (currentPage.includes('teacher-dashboard')) {
        if (isAuthenticated === 'true' && userType === 'TEACHER') {
            return;
        }
    }

    // Only redirect if not authenticated
    if (!isAuthenticated || !userType) {
        localStorage.clear();
        window.location.replace('/index.html');
    }
}
