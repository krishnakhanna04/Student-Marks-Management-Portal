// Show/Hide sections
// Add this function at the beginning of the file
window.cachedSubjects = [];
window.cachedTeachers = [];
async function loadData(type) {
    try {
        console.log(`Fetching ${type} data...`);
        const response = await fetch(`/api/admin/${type}`);
        if (!response.ok) {
            throw new Error(`Failed to load ${type}`);
        }

        const data = await response.json();
        console.log(`Retrieved ${type} data:`, data);
        
        // Store the data in localStorage
        localStorage.setItem(`${type}Data`, JSON.stringify(data));
        
        // Display data based on type
        switch(type) {
            case 'classes':
                displayClasses(data);
                break;
            case 'teachers':
            case 'students':
            case 'courses':
            case 'subjects':
                displayData(type, data);
                break;
            default:
                console.error('Unknown data type:', type);
        }
    } catch (error) {
        console.error(`Error loading ${type}:`, error);
        const container = document.getElementById(`${type}-list`);
        if (container) {
            container.innerHTML = `
                <div class="alert alert-danger">
                    Error loading ${type}: ${error.message}
                </div>
            `;
        }
    }
}

// Update the showSection function
function showSection(sectionName) {
    // Hide all sections first
    document.querySelectorAll('.management-section').forEach(section => {
        section.style.display = 'none';
    });
    
    // Show the selected section
    const selectedSection = document.getElementById(`${sectionName}-section`);
    if (selectedSection) {
        selectedSection.style.display = 'block';
        // Load data for the section
        loadData(sectionName).catch(error => {
            console.error(`Error in showSection for ${sectionName}:`, error);
        });
    }
}

// Add this when the document loads
document.addEventListener('DOMContentLoaded', () => {
    // Show initial section (teachers)
    showSection('teachers');
});

// Show/Hide forms
// Change 'classe' to 'classes' in your HTML and JS
// Update the showForm function
function showForm(type, data = null) {
    if (type === 'class') {
        const formContainer = document.getElementById('classForm');
        if (!formContainer) {
            console.error(`Form container not found for type: ${type}`);
            return;
        }
        formContainer.style.display = 'block';

        // Load course options
        fetch('/api/admin/courses')
            .then(response => response.json())
            .then(courses => {
                const courseSelect = document.getElementById('classCourseSelect');
                if (courseSelect) {
                    courseSelect.innerHTML = `
                        <option value="">Select Course</option>
                        ${courses.map(course => `
                            <option value="${course.courseId}" data-coursecode="${course.coursecode}">${course.courseName}</option>
                        `).join('')}
                    `;
                    // Set selected course if editing
                    if (data && data.courseId) {
                        courseSelect.value = data.courseId;
                        // Trigger change event to load subjects/teachers/students
                        courseSelect.dispatchEvent(new Event('change'));
                    }
                }

                // Set other fields after course dropdown is ready
                setTimeout(() => {
                    // Set classId
                    const classIdInput = document.getElementById('classId');
                    if (classIdInput && data && data.classId) {
                        classIdInput.value = data.classId;
                    }

                    // Set subject-teacher pairs
                    const container = document.getElementById('subjectTeacherPairs');
                    if (container && data && Array.isArray(data.subjectTeachers)) {
                        container.innerHTML = '';
                        data.subjectTeachers.forEach(pair => {
                            addSubjectTeacherPair(container, window.cachedSubjects || [], window.cachedTeachers || []);
                            // Set selected values for the last added pair
                            const pairs = container.querySelectorAll('.subject-teacher-pair');
                            const lastPair = pairs[pairs.length - 1];
                            if (lastPair) {
                                const subjectSelect = lastPair.querySelector('.subject-select');
                                const teacherSelect = lastPair.querySelector('.teacher-select');
                                if (subjectSelect && pair.subjectId) subjectSelect.value = pair.subjectId;
                                if (teacherSelect && pair.teacher && pair.teacher.teacherId) teacherSelect.value = pair.teacher.teacherId;
                            }
                        });
                    }

                    // Set selected students
                    if (data && Array.isArray(data.students)) {
                        data.students.forEach(student => {
                            const checkbox = document.getElementById(`student_${student._id}`);
                            if (checkbox) checkbox.checked = true;
                        });
                    }
                }, 300); // Wait for dropdowns to populate
            })
            .catch(error => {
                console.error('Error loading courses:', error);
                alert('Failed to load courses');
            });
        return;
    }

    // Handle other types using modals
    const formType = type === 'courses' ? 'course' : 
                     type.endsWith('s') ? type.slice(0, -1) : type;
    const formContainer = document.getElementById(`${formType}Modal`);
    
    if (!formContainer) {
        console.error(`Form container not found for type: ${formType}`);
        return;
    }

    // Reset form before showing
    const form = formContainer.querySelector('form');
    if (form) {
        form.reset();
        
        // Clear hidden fields
        const hiddenInputs = form.querySelectorAll('input[type="hidden"]');
        hiddenInputs.forEach(input => input.value = '');

        // If editing, populate form fields
        if (data) {
            Object.keys(data).forEach(key => {
                const input = form.querySelector(`[name="${key}"]`);
                if (input) {
                    input.value = data[key];
                }
            });
            // Also set the hidden _id field if present
            if (data._id) {
                form.querySelector('[name="_id"]').value = data._id;
            }
            if (data.teacherId) {
                form.querySelector('[name="teacherId"]').value = data.teacherId;
            }
        }
    }

    // Show modal using Bootstrap
    const modal = new bootstrap.Modal(formContainer);
    modal.show();
}

// Update the editItem function
// Add this function near the top of the file
async function loadRelatedData() {
    try {
        const [students, subjects, teachers] = await Promise.all([
            fetch('/api/admin/students').then(res => res.json()),
            fetch('/api/admin/subjects').then(res => res.json()),
            fetch('/api/admin/teachers').then(res => res.json())
        ]);

        // Update dropdowns
        updateDropdowns(students, subjects, teachers);
    } catch (error) {
        console.error('Error loading related data:', error);
    }
}

// Add this helper function
function updateDropdowns(students, subjects, teachers) {
    // Update subject dropdown
    const subjectSelect = document.querySelector('.subject-select');
    if (subjectSelect) {
        subjectSelect.innerHTML = `
            <option value="">Select Subject</option>
            ${subjects.map(subject => `
                <option value="${subject.subjectId}">${subject.subjectName}</option>
            `).join('')}
        `;
    }

    // Update teacher dropdown
    const teacherSelect = document.querySelector('.teacher-select');
    if (teacherSelect) {
        teacherSelect.innerHTML = `
            <option value="">Select Teacher</option>
            ${teachers.map(teacher => `
                <option value="${teacher.teacherId}">${teacher.firstName} ${teacher.lastName}</option>
            `).join('')}
        `;
    }
}

// Replace the existing editItem function with this version
// Update the editItem function to handle teacherId
function editItem(type, itemData) {
    try {
        if (typeof itemData === 'string') {
            try {
                itemData = JSON.parse(itemData);
            } catch (error) {
                console.error('Error parsing item data:', error);
                return;
            }
        }
        showForm(type, itemData); // Pass the object directly
    } catch (error) {
        console.error('Error in editItem:', error);
    }
}

async function displayData(type, items) {
    const container = document.getElementById(`${type}-list`);
    container.innerHTML = '';
    const table = document.createElement('table');
    table.className = 'data-table';
    const thead = document.createElement('thead');
    let headers = [];
    
    switch(type) {
        case 'teachers': {
            headers = ['ID', 'First Name', 'Last Name', 'Email', 'Phone', 'Address', 'Date of Birth', 'Hire Date', 'Actions'];
            break;
        }
        case 'students': {
            headers = ['ID', 'First Name', 'Last Name', 'Email', 'Phone', 'Address', 'Course Code', 'Date of Birth', 'Enrollment Date', 'Actions'];
            break;
        }
        case 'courses': {
            headers = ['ID', 'Course Code', 'Course Name', 'Credits', 'Actions'];
            break;
        }
        case 'subjects': {
            headers = ['ID', 'Subject Name', 'Course ID', 'Actions'];
            break;
        }
        case 'classes': {
            headers = ['Class ID', 'Course', 'Subject-Teacher Pairs', 'Students', 'Actions'];
            break;
        }
    }
    
    thead.innerHTML = `<tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr>`;
    table.appendChild(thead);

    const tbody = document.createElement('tbody');
    for (const item of items) {
        const tr = document.createElement('tr');
        let cells = [];
        
        switch(type) {
            case 'teachers': {
                cells = [
                    item.teacherId,
                    item.firstName,
                    item.lastName,
                    item.emailid,
                    item.phoneNo,
                    item.address,
                    new Date(item.DateOfBirth).toLocaleDateString(),
                    new Date(item.hiredate).toLocaleDateString()
                ];
                tr.innerHTML = `
                    ${cells.map(cell => `<td>${cell || ''}</td>`).join('')}
                    <td class="action-buttons">
                        <button class="btn btn-success" onclick='editItem("teachers", ${JSON.stringify(item).replace(/'/g, "\\'")})'>Edit</button>
                        <button class="btn btn-danger" onclick="deleteItem('teachers', '${item.teacherId}')">Delete</button>
                    </td>
                `;
                break;
            }
            case 'students': {
                cells = [
                    item._id, // Just use _id directly since that's what's in the database
                    item.firstName,
                    item.lastName,
                    item.emailid,
                    item.phoneNo,
                    item.address,
                    item.courseCode, 
                    new Date(item.DateOfBirth).toLocaleDateString(),
                    new Date(item.enrollmentdate).toLocaleDateString()
                ];
                tr.innerHTML = `
                    ${cells.map(cell => `<td>${cell || ''}</td>`).join('')}
                    <td class="action-buttons">
                        <button class="btn btn-success" onclick='editItem("students", ${JSON.stringify(item)})'>Edit</button>
                        <button class="btn btn-danger" onclick="deleteItem('students', '${item._id}')">Delete</button>
                    </td>
                `;
                break;
            }
            case 'courses': {
                cells = [item.courseId, item.coursecode, item.courseName, item.credit];
                tr.innerHTML = `
                    ${cells.map(cell => `<td>${cell || ''}</td>`).join('')}
                    <td class="action-buttons">
                        <button class="btn btn-success" onclick='editItem("courses", ${JSON.stringify(item)})'>Edit</button>
                        <button class="btn btn-danger" onclick="deleteItem('courses', '${item._id}')">Delete</button>
                    </td>
                `;
                break;
            }
            case 'subjects': {
                cells = [item.subjectId, item.subjectName, item.courseId];
                tr.innerHTML = `
                    ${cells.map(cell => `<td>${cell || ''}</td>`).join('')}
                    <td class="action-buttons">
                        <button class="btn btn-success" onclick='editItem("subjects", ${JSON.stringify(item)})'>Edit</button>
                        <button class="btn btn-danger" onclick="deleteItem('subjects', '${item._id}')">Delete</button>
                    </td>
                `;
                break;
            }
            case 'classes': {
                cells = [
                    item.classId || '',
                    `<strong>${item.courseName || 'N/A'}</strong><br>
                     <small>Course ID: ${item.courseId || 'N/A'}</small>`,
                    item.subjectTeachers ? item.subjectTeachers.map(st => {
                        const teacherId = st.teacher ? st.teacher.teacherId : '';
                        const subjectId = st.subjectId || '';
                        return `<div class="subject-teacher-item">
                            <strong>Subject:</strong> ${subjectId}<br>
                            <strong>Teacher:</strong> ${teacherId}
                        </div>`;
                    }).join('<hr>') : '',
                    item.students ? item.students.length + ' students' : 'No students'
                ];
                break;
                
            }
        }

        switch(type) {
    case 'teachers': {
        tr.innerHTML = `
            ${cells.map(cell => `<td>${cell || ''}</td>`).join('')}
            <td class="action-buttons">
                <button class="btn btn-success" onclick='editItem("teachers", ${JSON.stringify(item).replace(/'/g, "\\'")})'>Edit</button>
                <button class="btn btn-danger" onclick="deleteItem('teachers', '${item.teacherId}')">Delete</button>
            </td>
        `;
        break;
    }
    case 'students': {
        tr.innerHTML = `
            ${cells.map(cell => `<td>${cell || ''}</td>`).join('')}
            <td class="action-buttons">
                <button class="btn btn-success" onclick='editItem("students", ${JSON.stringify(item)})'>Edit</button>
                <button class="btn btn-danger" onclick="deleteItem('students', '${item._id}')">Delete</button>
            </td>
        `;
        break;
    }
    // ...repeat for other types as needed...
    default: {
        tr.innerHTML = `
            ${cells.map(cell => `<td>${cell || ''}</td>`).join('')}
            <td class="action-buttons">
                <button class="btn btn-success" onclick='editItem("${type}", ${JSON.stringify(item).replace(/'/g, "\\'")})'>Edit</button>
                <button class="btn btn-danger" onclick="deleteItem('${type}', '${item._id || item.classId}')">Delete</button>
            </td>
        `;
    }
}
        tbody.appendChild(tr);
    }

    table.appendChild(tbody);
    container.appendChild(table);
}

// Keep only one DOMContentLoaded event listener at the root level
document.addEventListener('DOMContentLoaded', () => {
    const userEmail = localStorage.getItem('userEmail');
    
    // Update the fetch URL to use the AdminController endpoint
    if (userEmail) {
        fetch(`/api/admin/admin/${userEmail}`)  // This matches the AdminController endpoint
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to fetch admin profile');
                }
                return response.json();
            })
            .then(adminData => {
                const adminTitle = document.querySelector('.sidebar h2');
                if (adminTitle) {
                    adminTitle.textContent = `Admin (${adminData.firstName} ${adminData.lastName})`;
                }
            })
            .catch(error => {
                console.error('Error loading admin data:', error);
                const adminTitle = document.querySelector('.sidebar h2');
                if (adminTitle) {
                    adminTitle.textContent = `Admin (${userEmail})`;
                }
            });
    }

    // Replace the nested DOMContentLoaded with direct course select handler
    showSection('teachers');
    
    // Update the course select change listener
    const courseSelect = document.getElementById('classCourseSelect');
    if (courseSelect) {
        courseSelect.addEventListener('change', async (e) => {
            const selectedOption = courseSelect.options[courseSelect.selectedIndex];
            const selectedCourseCode = selectedOption.getAttribute('data-coursecode');

            // Load subjects, teachers, and students
            const [subjects, teachers, students] = await Promise.all([
                fetch('/api/admin/subjects').then(res => res.json()),
                fetch('/api/admin/teachers').then(res => res.json()),
                fetch('/api/admin/students').then(res => res.json())
            ]);

            // Filter subjects whose courseId matches selected coursecode
            const filteredSubjects = subjects.filter(subject => subject.courseId === selectedCourseCode);

            // Update student checkboxes (unchanged)
            const studentContainer = document.getElementById('classStudentSelect');
            if (studentContainer) {
                studentContainer.innerHTML = students.length > 0 
                    ? students.map(student => `
                        <div class="form-check">
                            <input type="checkbox" 
                                   class="form-check-input student-checkbox" 
                                   value="${student._id}" 
                                   id="student_${student._id}">
                            <label class="form-check-label" for="student_${student._id}">
                                ${student.firstName} ${student.lastName}
                            </label>
                        </div>
                    `).join('')
                    : '<p>No students found.</p>';
            }

            // Clear existing subject-teacher pairs
            const container = document.getElementById('subjectTeacherPairs');
            if (container) {
                container.innerHTML = '';
            }

            // Add new pair with filtered subjects
            const pairDiv = document.createElement('div');
            pairDiv.className = 'subject-teacher-pair form-group mb-3';
            pairDiv.innerHTML = `
                <div class="row">
                    <div class="col-md-5">
                        <label>Subject</label>
                        <select class="form-control subject-select" required>
                            <option value="">Select Subject</option>
                            ${filteredSubjects.map(subject => `
                                <option value="${subject.subjectId}">${subject.subjectName}</option>
                            `).join('')}
                        </select>
                    </div>
                    <div class="col-md-5">
                        <label>Teacher</label>
                        <select class="form-control teacher-select" required>
                            <option value="">Select Teacher</option>
                            ${teachers.map(teacher => `
                                <option value="${teacher.teacherId}">${teacher.firstName} ${teacher.lastName}</option>
                            `).join('')}
                        </select>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="button" class="btn btn-danger" onclick="this.closest('.subject-teacher-pair').remove()">
                            Remove
                        </button>
                    </div>
                </div>
            `;
            container.appendChild(pairDiv);
        });
    }

    // Remove the nested DOMContentLoaded event listener
    // Add this function to hide forms
    function hideForm(type) {
        if (type === 'class') {
            const formContainer = document.getElementById('classForm');
            if (formContainer) {
                formContainer.style.display = 'none';
                if (formContainer instanceof HTMLFormElement) {
                    formContainer.reset();
                }
                // Clear subject-teacher pairs
                const subjectTeacherPairs = document.getElementById('subjectTeacherPairs');
                if (subjectTeacherPairs) {
                    subjectTeacherPairs.innerHTML = '';
                }
                // Clear student selections
                const studentContainer = document.getElementById('classStudentSelect');
                if (studentContainer) {
                    studentContainer.innerHTML = '';
                }
            }
        } else {
            // For other types using modals
            const modalId = `#${type}Modal`;
            const modal = $(modalId);
            if (modal.length) {
                modal.modal('hide');
            }
        }
    }

    // Update the class form section with cancel button handler
    const classForm = document.getElementById('classForm');
    if (classForm) {
        // Add submit event listener
        classForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const courseSelect = document.getElementById('classCourseSelect');
            const selectedCourse = courseSelect.options[courseSelect.selectedIndex];
            const classId = document.getElementById('classId').value; // Get the class ID value
    
            // Get subject-teacher pairs with both subject and teacher IDs
            const subjectTeacherPairs = Array.from(document.getElementsByClassName('subject-teacher-pair'))
                .map(pair => {
                    const teacherSelect = pair.querySelector('.teacher-select');
                    const subjectSelect = pair.querySelector('.subject-select');
                    if (!teacherSelect.value || !subjectSelect.value) return null;
    
                    return {
                        teacher: {
                            teacherId: teacherSelect.value
                        },
                        subjectId: subjectSelect.value
                    };
                })
                .filter(pair => pair !== null);
    
            // Get selected students with their actual IDs
            // In the class form submit handler, update the students mapping
            const selectedStudents = Array.from(document.querySelectorAll('.student-checkbox:checked'))
                .map(checkbox => ({
                    _id: checkbox.value || null  // Use the MongoDB _id from the checkbox value
                }));
    
            const classData = {
                courseId: selectedCourse.value,
                courseName: selectedCourse.text,
                classId: classId, // Use the input class ID instead of hardcoded value
                subjectTeachers: subjectTeacherPairs,
                students: selectedStudents,
                _class: "com.academicportal.model.ClassRoom"
            };
    
            try {
                console.log('Sending class data:', classData);
                const response = await fetch('/api/admin/classes', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(classData)
                });
    
                if (!response.ok) {
                    const errorText = await response.text();
                    console.error('Server response:', errorText);
                    throw new Error(`Failed to create class: ${errorText}`);
                }
    
                alert('Class created successfully!');
                hideForm('class');
                loadData('classes');
            } catch (error) {
                console.error('Error:', error);
                alert('Error creating class: ' + error.message);
            }
        });
    }

    // Add cancel button handler
    const cancelButton = classForm.querySelector('button[type="button"]');
    if (cancelButton) {
        cancelButton.addEventListener('click', () => {
            hideForm('class');
        });
    }

    // Add subject form listener
    // Update the subject form submit handler
    const subjectForm = document.getElementById('subjectForm');
    if (subjectForm) {
        subjectForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData.entries());
            const isEdit = data._id ? true : false;
    
            try {
                const subjectData = {
                    ...data,
                    _class: "com.academicportal.model.Subject"
                };
    
                const response = await fetch(`/api/admin/subjects${isEdit ? '/' + data._id : ''}`, {
                    method: isEdit ? 'PUT' : 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(subjectData)
                });
    
                if (!response.ok) {
                    const errorText = await response.text();
                    throw new Error(`Failed to save subject: ${errorText}`);
                }
    
                $('#subjectModal').modal('hide');
                e.target.reset();
                await loadData('subjects');
                alert('Subject saved successfully!');
            } catch (error) {
                console.error('Error submitting subject form:', error);
                alert('Error saving subject: ' + error.message);
            }
        });
    }

    // Teacher form submission handler
    const teacherForm = document.getElementById('teacherForm');
    if (teacherForm) {
        teacherForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const formData = new FormData(teacherForm);
            const data = Object.fromEntries(formData.entries());
            data._class = "com.academicportal.model.Teacher";
            const isEdit = !!data._id;
            try {
                const url = isEdit
                    ? `/api/admin/teachers/${data.teacherId}`
                    : '/api/admin/teachers';
                const method = isEdit ? 'PUT' : 'POST';
                const response = await fetch(url, {
                    method,
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                if (!response.ok) {
                    const errorText = await response.text();
                    throw new Error(errorText);
                }
                $('#teacherModal').modal('hide');
                teacherForm.reset();
                await loadData('teachers');
                alert(isEdit ? 'Teacher updated successfully!' : 'Teacher added successfully!');
            } catch (error) {
                alert('Failed to save teacher: ' + error.message);
            }
        });
    }

    // Student form submission handler
    const studentForm = document.getElementById('studentForm');
    if (studentForm) {
        studentForm.addEventListener('submit', async function(e) {
            e.preventDefault();

            const formData = new FormData(studentForm);
            const data = Object.fromEntries(formData.entries());
            data._class = "com.academicportal.model.Student"; // For MongoDB class mapping

            try {
                const response = await fetch('/api/admin/students', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });

                if (!response.ok) {
                    const errorText = await response.text();
                    throw new Error(errorText);
                }

                // Hide modal, reset form, and reload student list
                $('#studentsModal').modal('hide');
                studentForm.reset();
                await loadData('students');
                alert('Student added successfully!');
            } catch (error) {
                alert('Failed to add student: ' + error.message);
            }
        });
    }

    
   
}); // Remove the nested DOMContentLoaded listener

// Remove duplicate loadRelatedData function and keep only the main implementation at the top
// Remove duplicate addSubjectTeacherPair function
// Remove duplicate editItem and deleteItem functions
// Add the missing editItem and deleteItem functions
async function deleteItem(type, id) {
    if (!id) {
        alert('Error: Cannot delete item without an ID');
        return;
    }
    if (!confirm(`Are you sure you want to delete this ${type.slice(0, -1)}?`)) {
        return;
    }
    try {
        const endpoint = `/api/admin/${type}/${id}`;
        const response = await fetch(endpoint, { method: 'DELETE' });
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(errorText);
        }
        await loadData(type);
        alert(`${type.slice(0, -1)} deleted successfully`);
    } catch (error) {
        alert(`Failed to delete ${type.slice(0, -1)}: ${error.message}`);
    }
}
function showSubjectModal(mode, subject = null) {
    const modalTitle = document.getElementById('subjectModalTitle');
    const form = document.getElementById('subjectForm');
    const courseSelect = document.getElementById('courseId');
    
    modalTitle.textContent = mode === 'add' ? 'Add Subject' : 'Edit Subject';
    form.reset();
    
    // If editing, set the values directly
    if (mode === 'edit' && subject) {
        document.getElementById('subjectId').value = subject.subjectId;
        document.getElementById('subjectName').value = subject.subjectName;
        courseSelect.value = subject.courseId;
    }
    
    $('#subjectModal').modal('show');
}

function displayClasses(classes) {
    const classesList = document.getElementById('classes-list'); // Changed from 'classes-section' to 'classes-list'
    if (!classes || classes.length === 0) {
        classesList.innerHTML = '<p>No classes found.</p>';
        return;
    }

    const table = document.createElement('table');
    table.className = 'table';
    table.innerHTML = `
        <thead>
            <tr>
                <th>Class ID</th>
                <th>Course</th>
                <th>Subject-Teacher Pairs</th>
                <th>Students</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            ${classes.map(classRoom => `
                <tr>
                    <td>${classRoom.classId || 'N/A'}</td>
                    <td>
                        <strong>${classRoom.courseName || 'N/A'}</strong><br>
                        <small>Course ID: ${classRoom.courseId || 'N/A'}</small>
                    </td>
                    <td>
                        ${classRoom.subjectTeachers?.map(st => `
                            <div class="subject-teacher-item">
                                <strong>Subject:</strong> ${st.subjectId || 'N/A'}<br>
                                ${st.teacher ? `
                                    <strong>Teacher:</strong> ${st.teacher.teacherId || 'N/A'}
                                ` : 'No teacher assigned'}
                            </div>
                        `).join('<hr>') || 'No subject-teacher pairs'}
                    </td>
                    <td>
                        ${classRoom.students?.map(student => `
                            <div class="student-item">ID: ${student._id || 'N/A'}</div>
                        `).join('') || 'No students'}
                    </td>
                    <td>
                        <button class="btn btn-success" onclick="editItem('class', ${JSON.stringify(classRoom).replace(/"/g, '&quot;')})">Edit</button>
                        <button class="btn btn-danger" onclick="deleteItem('classes', '${classRoom.id}')">Delete</button>
                    </td>
                </tr>
            `).join('')}
        </tbody>
    `;

    classesList.innerHTML = '';
    classesList.appendChild(table);
}

// Add this function to handle course form submissio
// Move this function before the DOMContentLoaded event
async function handleCourseFormSubmit(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    // Use courseId as the unique identifier
    const courseData = {
        courseId: data.courseId, // Admin input
        courseName: data.courseName,
        coursecode: data.coursecode,
        credit: parseInt(data.credit),
        _class: "com.academicportal.model.Course"
    };

    try {
        // Use courseId for PUT (edit) and DELETE
        const url = `/api/admin/courses${data.courseId ? `/${data.courseId}` : ''}`;
        const method = data.courseId ? 'PUT' : 'POST';
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(courseData)
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Failed to save course: ${errorText}`);
        }

        $('#courseModal').modal('hide');
        form.reset();
        await loadData('courses');
        
    } catch (error) {
        console.error('Error saving course:', error);
        alert('Failed to save course: ' + error.message);
    }
}

// Update the course form listener in the DOMContentLoaded event
document.addEventListener('DOMContentLoaded', () => {
    const courseForm = document.getElementById('courseForm');
    if (courseForm) {
        // Remove the removeEventListener line since handleFormSubmit doesn't exist
        courseForm.addEventListener('submit', handleCourseFormSubmit);
    }

    const addPairBtn = document.getElementById('addSubjectTeacherPairBtn');
    const courseSelect = document.getElementById('classCourseSelect');
    let cachedSubjects = [];
    let cachedTeachers = [];

    if (courseSelect) {
        courseSelect.addEventListener('change', async (e) => {
            const selectedOption = courseSelect.options[courseSelect.selectedIndex];
            const selectedCourseCode = selectedOption.getAttribute('data-coursecode');

            const [subjects, teachers, students] = await Promise.all([
                fetch('/api/admin/subjects').then(res => res.json()),
                fetch('/api/admin/teachers').then(res => res.json()),
                fetch('/api/admin/students').then(res => res.json())
            ]);

            cachedSubjects = subjects.filter(subject => subject.courseId === selectedCourseCode);
            cachedTeachers = teachers;

            // Enable the add pair button only if there are subjects and teachers
            if (addPairBtn) {
                addPairBtn.disabled = !(cachedSubjects.length && cachedTeachers.length);
            }

            // Update student checkboxes (unchanged)
            const studentContainer = document.getElementById('classStudentSelect');
            if (studentContainer) {
                studentContainer.innerHTML = students.length > 0 
                    ? students.map(student => `
                        <div class="form-check">
                            <input type="checkbox" 
                                   class="form-check-input student-checkbox" 
                                   value="${student._id}" 
                                   id="student_${student._id}">
                            <label class="form-check-label" for="student_${student._id}">
                                ${student.firstName} ${student.lastName}
                            </label>
                        </div>
                    `).join('')
                    : '<p>No students found.</p>';
            }

            // Clear and add initial subject-teacher pair
            const container = document.getElementById('subjectTeacherPairs');
            if (container) {
                container.innerHTML = '';
                addSubjectTeacherPair(container, cachedSubjects, cachedTeachers);
            }
        });
    }

    if (addPairBtn) {
        addPairBtn.addEventListener('click', () => {
            if (cachedSubjects.length && cachedTeachers.length) {
                const container = document.getElementById('subjectTeacherPairs');
                addSubjectTeacherPair(container, cachedSubjects, cachedTeachers);
            }
        });
    }
});

// Helper function to add a subject-teacher pair
function addSubjectTeacherPair(container, subjects, teachers) {
    const pairDiv = document.createElement('div');
    pairDiv.className = 'subject-teacher-pair form-group mb-3';
    pairDiv.innerHTML = `
        <div class="row">
            <div class="col-md-5">
                <label>Subject</label>
                <select class="form-control subject-select" required>
                    <option value="">Select Subject</option>
                    ${subjects.map(subject => `
                        <option value="${subject.subjectId}">${subject.subjectName}</option>
                    `).join('')}
                </select>
            </div>
            <div class="col-md-5">
                <label>Teacher</label>
                <select class="form-control teacher-select" required>
                    <option value="">Select Teacher</option>
                    ${teachers.map(teacher => `
                        <option value="${teacher.teacherId}">${teacher.firstName} ${teacher.lastName}</option>
                    `).join('')}
                </select>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="button" class="btn btn-danger" onclick="this.closest('.subject-teacher-pair').remove()">
                    Remove
                </button>
            </div>
        </div>
    `;
    container.appendChild(pairDiv);
}
