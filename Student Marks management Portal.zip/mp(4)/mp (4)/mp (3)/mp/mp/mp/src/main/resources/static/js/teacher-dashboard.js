const BASE_URL = window.location.origin; // This will get the correct server URL

document.addEventListener('DOMContentLoaded', () => {
    // Get user info from localStorage
    const userEmail = localStorage.getItem('userEmail');
    const userType = localStorage.getItem('userType');
    
    if (!userEmail || userType !== 'TEACHER') {
        window.location.replace('/index.html');
        return;
    }

    // Load initial data
    loadTeacherProfile();
    
    // Show dashboard by default
    showSection('dashboard');

    // Add click handlers for navigation
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const section = e.target.getAttribute('data-section');
            showSection(section);
        });
    });

    // Add logout handler
    const logoutButton = document.getElementById('logoutBtn');
    if (logoutButton) {
        logoutButton.addEventListener('click', () => {
            localStorage.clear();
            window.location.replace('/index.html');
        });
    }
});

function showSection(sectionName) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(sec => sec.style.display = 'none');
    // Remove 'active' class from all sidebar links
    document.querySelectorAll('.nav-links a').forEach(link => link.classList.remove('active'));
    // Show the selected section
    const section = document.getElementById(sectionName + '-section');
    if (section) section.style.display = 'block';
    // Add 'active' class to the clicked link
    document.querySelectorAll(`.nav-links a[data-section="${sectionName}"]`).forEach(link => link.classList.add('active'));

    // Load section specific data
    switch(sectionName) {
        case 'dashboard':
            const teacherId = localStorage.getItem('teacherId');
            if (teacherId) {
                loadTeacherClasses(teacherId); // <-- Add this line
            }
            updateDashboard();
            break;
        case 'classes':
            const teacherId2 = localStorage.getItem('teacherId');
            if (teacherId2) {
                loadTeacherClasses(teacherId2);
            }
            break;
        case 'profile':
            const teacherData = JSON.parse(localStorage.getItem('teacherData') || '{}');
            updateTeacherUI(teacherData);
            break;
        case 'manage-marks':
            loadAllMarksheetNames();
            break;
        case 'marks':
            loadAllMarksheetNames();
            // Optionally hide the form/table if open:
            document.getElementById('marksheetFormContainer').style.display = 'none';
            document.getElementById('marksheetTableContainer').innerHTML = '';
            break;
    }
}

async function loadTeacherProfile() {
    try {
        const userEmail = localStorage.getItem('userEmail');
        if (!userEmail) {
            throw new Error('User email not found in localStorage');
        }

        const response = await fetch(`/api/teacher/profile/${encodeURIComponent(userEmail)}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const teacherData = await response.json();
        if (!teacherData || !teacherData.teacherId) {
            throw new Error('Invalid teacher data received');
        }

        // Update teacher name in sidebar
        const teacherNameElement = document.getElementById('teacherName');
        if (teacherNameElement) {
            teacherNameElement.textContent = `${teacherData.firstName} ${teacherData.lastName}`;
        }

        // Store teacher data
        localStorage.setItem('teacherId', teacherData.teacherId);
        localStorage.setItem('teacherData', JSON.stringify(teacherData));
    } catch (error) {
        console.error('Error loading teacher profile:', error);
    }
}

async function loadTeacherClasses(teacherId) {
    try {
        const response = await fetch(`/api/teacher/classes/${teacherId}`);
        if (!response.ok) {
            throw new Error('Failed to load classes');
        }

        const classes = await response.json();
        displayClasses(classes);
    } catch (error) {
        console.error('Error loading classes:', error);
        document.getElementById('classes-section').innerHTML = `
            <div class="alert alert-danger">
                Error loading classes: ${error.message}
            </div>`;
    }
}

let teacherClasses = []; // global variable

function displayClasses(classes) {
    teacherClasses = classes; // store for later use

    const classesList = document.getElementById('classes-list');
    if (!classesList) {
        console.error('Classes list container not found');
        return;
    }

    if (!classes || classes.length === 0) {
        classesList.innerHTML = '<div class="alert alert-info">No classes found.</div>';
        return;
    }

    classesList.innerHTML = `
        <table class="teacher-table">
            <thead>
                <tr>
                    <th>Class ID</th>
                    <th>Course Name</th>
                    <th>Subjects</th>
                    <th>Total Students</th>
                </tr>
            </thead>
            <tbody>
                ${classes.map(classItem => `
                    <tr>
                        <td>${classItem.classId || 'N/A'}</td>
                        <td>${classItem.courseName || 'N/A'}</td>
                        <td>${classItem.subjectTeachers?.map(st => st.subjectId).join(', ') || 'No subjects'}</td>
                        <td>${classItem.students?.length || 0} students</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;

    // After fetching classes and students data:
    document.getElementById('totalClasses').textContent = classes.length;
    const students = classes.flatMap(cls => cls.students || []);
    const subjects = classes.flatMap(cls => cls.subjectTeachers?.map(st => st.subjectId) || []);
    document.getElementById('totalStudents').textContent = students.length;
    document.getElementById('totalSubjects').textContent = [...new Set(subjects)].length;
}

//function viewClassDetails(classId) {
    //fetch(`/api/teacher/classes/${classId}/students`)
      //  .then(response => response.json())
       // .then(data => {
         //   const students = Array.isArray(data.students) ? data.students : [];
          //  const modalHtml = `
            //    <div class="modal" id="studentDetailsModal">
              //      <div class="modal-content">
                //        <div class="modal-header">
                  //          <h3>Class Students</h3>
                    //        <span class="close-modal" onclick="closeModal()">&times;</span>
                      //  </div>
                        //<div class="modal-body">
                          //  <table class="teacher-table">
                            //    <thead>
                              //      <tr>
                                //        <th>Student ID</th>
                                  //      <th>Name</th>
                                    //</tr>
                              //  </thead>
                                //<tbody>
                                  //  ${students.map(student => `
                                //        <tr>
                              //              <td>${student._id || student.id || ''}</td>
                            //                <td>${student.firstName || ''} ${student.lastName || ''}</td>
                          //              </tr>
                        //            `).join('')}
                      //          </tbody>
                    //        </table>
                  //      </div>
                //    </div>
              //  </div>
            //`;
            //document.body.insertAdjacentHTML('beforeend', modalHtml);
          //  document.getElementById('studentDetailsModal').style.display = 'block';
        //})
      //  .catch(error => {
    //        console.error('Error fetching student details:', error);
  //      });
//}

function closeModal() {
    const modal = document.getElementById('studentDetailsModal');
    if (modal) {
        modal.remove();
    }
}

// Add event listeners for navigation
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const section = e.target.getAttribute('data-section');
            showSection(section);
        });
    });
});


function updateTeacherUI(teacherData) {
    document.getElementById('teacherFullName').textContent = `${teacherData.firstName} ${teacherData.lastName}`;
    document.getElementById('teacherEmail').textContent = teacherData.emailid;
    document.getElementById('teacherPhone').textContent = teacherData.phoneNo;
    document.getElementById('teacherAddress').textContent = teacherData.address;
    document.getElementById('teacherId').textContent = teacherData.teacherId;
    document.getElementById('teacherHireDate').textContent = new Date(teacherData.hiredate).toLocaleDateString();
}

function showMarksheetForm() {
    document.getElementById('marksheetFormContainer').style.display = 'block';
    document.getElementById('marksheetTableContainer').innerHTML = '';

    // Populate the class dropdown with each subject as a separate option
    const select = document.getElementById('marksheetClassSelect');
    select.innerHTML = '<option value="">Select Class & Subject</option>';
    teacherClasses.forEach(cls => {
        (cls.subjectTeachers || []).forEach(st => {
            // Use both classId and subjectId as value, separated by a delimiter (e.g., |)
            select.innerHTML += `<option value="${cls.classId}|${st.subjectId}">${cls.classId} - ${st.subjectId}</option>`;
        });
    });
}
window.showMarksheetForm = showMarksheetForm;

function hideMarksheetForm() {
    document.getElementById('marksheetFormContainer').style.display = 'none';
}

async function createMarksheet(event) {
    event.preventDefault();
    const form = event.target;
    const marksheetName = form.marksheetName.value;
    const classSubjectValue = form.classId.value;
    const totalMarks = form.totalMarks.value;
    const totalQuestions = parseInt(form.totalQuestions.value, 10);

    const [classId, subjectId] = classSubjectValue.split('|');
    const cls = teacherClasses.find(c => c.classId === classId);
    if (!cls || !cls.students || cls.students.length === 0) {
        document.getElementById('marksheetTableContainer').innerHTML = '<div class="alert alert-warning">No students found for this class.</div>';
        return;
    }

    // Before fetching student details:
    const studentIds = cls.students.map(s => s._id);
    let students = [];
    try {
        students = await fetchStudentsByIds(studentIds);
    } catch (err) {
        document.getElementById('marksheetTableContainer').innerHTML = '<div class="alert alert-danger">Failed to load student details.</div>';
        return;
    }

    // Generate table headers for questions
    let questionHeaders = '';
    for (let i = 1; i <= totalQuestions; i++) {
        questionHeaders += `<th>Q${i}</th>`;
    }

    // Generate table rows for each student
    let tableRows = students.map(stu => {
        let questionInputs = '';
        for (let i = 1; i <= totalQuestions; i++) {
            questionInputs += `<td>
        <input type="number" class="form-control question-mark" 
               data-student="${stu._id}" 
               name="q${i}_${stu._id}" min="0" max="${totalMarks}" required>
    </td>`;
        }
        return `
            <tr>
                <td>${stu._id || ''}</td>
                <td>${stu.firstName || ''}</td>
                <td>${stu.lastName || ''}</td>
                ${questionInputs}
                <td><input type="number" class="form-control" name="total_${stu._id}" min="0" max="${totalMarks}" required></td>
            </tr>
        `;
    }).join('');

    // Build the table
    let table = `
        <h4>${marksheetName} (${classId} - ${subjectId})</h4>
        <form id="marksheetSaveForm">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Student ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        ${questionHeaders}
                        <th>Total Marks</th>
                    </tr>
                </thead>
                <tbody>
                    ${tableRows}
                </tbody>
            </table>
            <button type="submit" class="btn btn-primary">Save Marksheet</button>
        </form>
    `;
    document.getElementById('marksheetTableContainer').innerHTML = table;
    hideMarksheetForm();

    // Add event listeners to auto-calculate total marks
    document.querySelectorAll('.question-mark').forEach(input => {
        input.addEventListener('input', function() {
            const studentId = this.getAttribute('data-student');
            const questionInputs = document.querySelectorAll(`.question-mark[data-student="${studentId}"]`);
            let sum = 0;
            questionInputs.forEach(qInput => {
                const val = parseFloat(qInput.value);
                if (!isNaN(val)) sum += val;
            });
            const totalInput = document.querySelector(`input[name="total_${studentId}"]`);
            if (totalInput) totalInput.value = sum;
        });
    });

   document.getElementById('marksheetSaveForm').onsubmit = async function(e) {
    e.preventDefault();

    const formData = new FormData(e.target);
    const marksheet = {
        marksheetName,
        classId,
        subjectId,
        totalMarks: Number(totalMarks),
        totalQuestions: Number(totalQuestions),
        students: []
    };

    students.forEach(stu => {
        let studentEntry = {
            studentId: stu._id,
            questions: [],
            total: Number(formData.get(`total_${stu._id}`))
        };
        for (let i = 1; i <= totalQuestions; i++) {
            studentEntry.questions.push(Number(formData.get(`q${i}_${stu._id}`)));
        }
        marksheet.students.push(studentEntry);
    });

    // Send to backend
    const response = await fetch('/api/teacher/marksheets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(marksheet)
    });

    if (response.ok) {
        alert('Marksheet saved successfully!');
        document.getElementById('marksheetTableContainer').innerHTML = ''; // Hide table
        loadAllMarksheetNames(); // Show all marksheet names
    } else {
        alert('Failed to save marksheet.');
    }
};
}
window.createMarksheet = createMarksheet;

// Placeholder for saving marksheet (implement backend call as needed)
function saveMarksheet(marksheetName, classId, subjectId, totalMarks, totalQuestions) {
    // Collect marks from the table and send to backend
    alert('Marksheet saved! (Implement backend logic)');
}

//window.showMarksheetForm = showMarksheetForm;
//window.hideMarksheetForm = hideMarksheetForm;
//window.createMarksheet = createMarksheet;

async function fetchStudentsByIds(studentIds) {
    if (!studentIds || studentIds.length === 0) return [];
    const response = await fetch(`/api/teacher/students?ids=${studentIds.join(',')}`);
    if (!response.ok) throw new Error('Failed to fetch student details');
    return await response.json();
}

async function loadAllMarksheetNames() {
    const res = await fetch('/api/teacher/marksheets');
    let html = '';
    if (!res.ok) {
        html = '<div class="alert alert-danger">Failed to load marksheets.</div>';
    } else {
        const marksheets = await res.json();
        if (!marksheets.length) {
            html = '<div>No marksheets found.</div>';
        } else {
            html = `
                <h4>All Marksheets</h4>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Marksheet Name</th>
                            <th>Class</th>
                            <th>Subject</th>
                            <th>Total Marks</th>
                            <th>Total Questions</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${marksheets.map((m, i) => `
                            <tr>
                                <td>${i + 1}</td>
                                <td>${m.marksheetName || ''}</td>
                                <td>${m.classId || ''}</td>
                                <td>${m.subjectId || ''}</td>
                                <td>${m.totalMarks || ''}</td>
                                <td>${m.totalQuestions || ''}</td>
                                <td>
                                    <button class="btn btn-sm btn-primary" onclick="editMarksheet('${m.id || m._id}')">Edit</button>
                                    <button class="btn btn-sm btn-danger" onclick="deleteMarksheet('${m.id || m._id}')">Delete</button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
        }
    }
    document.getElementById('marksheetListContainer').innerHTML = html;
}

async function deleteMarksheet(id) {
    if (!confirm('Are you sure you want to delete this marksheet?')) return;
    const res = await fetch(`/api/teacher/marksheets/${id}`, { method: 'DELETE' });
    if (res.ok) {
        alert('Marksheet deleted!');
        loadAllMarksheetNames();
    } else {
        alert('Failed to delete marksheet.');
    }
}

async function editMarksheet(id) {
    // Fetch the marksheet data
    const res = await fetch(`/api/teacher/marksheets/${id}`);
    if (!res.ok) {
        alert('Failed to fetch marksheet for editing.');
        return;
    }
    const marksheet = await res.json();

    // Fetch students for this class
    let students = [];
    try {
        // marksheet.students is assumed to be an array of {studentId, ...}
        const studentIds = (marksheet.students || []).map(s => s.studentId);
        students = await fetchStudentsByIds(studentIds);
    } catch (err) {
        document.getElementById('marksheetTableContainer').innerHTML = '<div class="alert alert-danger">Failed to load student details.</div>';
        return;
    }

    // Generate table headers for questions
    let questionHeaders = '';
    for (let i = 1; i <= marksheet.totalQuestions; i++) {
        questionHeaders += `<th>Q${i}</th>`;
    }

    // Generate table rows for each student, pre-filling marks
    let tableRows = students.map(stu => {
        const stuMark = (marksheet.students || []).find(s => s.studentId === stu._id) || {};
        let questionInputs = '';
        for (let i = 1; i <= marksheet.totalQuestions; i++) {
            const val = (stuMark.questions && stuMark.questions[i-1] != null) ? stuMark.questions[i-1] : '';
            questionInputs += `<td>
                <input type="number" class="form-control question-mark"
                       data-student="${stu._id}"
                       name="q${i}_${stu._id}" min="0" max="${marksheet.totalMarks}" value="${val}" required>
            </td>`;
        }
        return `
            <tr>
                <td>${stu._id || ''}</td>
                <td>${stu.firstName || ''}</td>
                <td>${stu.lastName || ''}</td>
                ${questionInputs}
                <td><input type="number" class="form-control" name="total_${stu._id}" min="0" max="${marksheet.totalMarks}" value="${stuMark.total || ''}" required></td>
            </tr>
        `;
    }).join('');

    // Build the table
    let table = `
        <h4>${marksheet.marksheetName} (${marksheet.classId} - ${marksheet.subjectId})</h4>
        <form id="marksheetSaveForm" data-edit-id="${id}">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Student ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        ${questionHeaders}
                        <th>Total Marks</th>
                    </tr>
                </thead>
                <tbody>
                    ${tableRows}
                </tbody>
            </table>
            <button type="submit" class="btn btn-primary">Update Marksheet</button>
            <button type="button" class="btn btn-secondary" onclick="hideMarksheetForm()">Cancel</button>
        </form>
    `;
    document.getElementById('marksheetTableContainer').innerHTML = table;
    document.getElementById('marksheetFormContainer').style.display = 'none';
    document.getElementById('marksheetTableContainer').scrollIntoView({ behavior: 'smooth' });

    // Auto-calculate total marks
    document.querySelectorAll('.question-mark').forEach(input => {
        input.addEventListener('input', function() {
            const studentId = this.getAttribute('data-student');
            const questionInputs = document.querySelectorAll(`.question-mark[data-student="${studentId}"]`);
            let sum = 0;
            questionInputs.forEach(qInput => {
                const val = parseFloat(qInput.value);
                if (!isNaN(val)) sum += val;
            });
            const totalInput = document.querySelector(`input[name="total_${studentId}"]`);
            if (totalInput) totalInput.value = sum;
        });
    });

    // Handle form submission for update
    document.getElementById('marksheetSaveForm').onsubmit = async function(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const updatedMarksheet = {
            marksheetName: marksheet.marksheetName,
            classId: marksheet.classId,
            subjectId: marksheet.subjectId,
            totalMarks: marksheet.totalMarks,
            totalQuestions: marksheet.totalQuestions,
            students: []
        };
        students.forEach(stu => {
            let studentEntry = {
                studentId: stu._id,
                questions: [],
                total: Number(formData.get(`total_${stu._id}`))
            };
            for (let i = 1; i <= marksheet.totalQuestions; i++) {
                studentEntry.questions.push(Number(formData.get(`q${i}_${stu._id}`)));
            }
            updatedMarksheet.students.push(studentEntry);
        });

        const res = await fetch(`/api/teacher/marksheets/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updatedMarksheet)
        });
        if (res.ok) {
            alert('Marksheet updated!');
            document.getElementById('marksheetTableContainer').innerHTML = '';
            loadAllMarksheetNames();
        } else {
            alert('Failed to update marksheet.');
        }
    };
}