package com.academicportal.service;

import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.academicportal.repository.AdminRepository;
import com.academicportal.repository.TeacherRepository;
import com.academicportal.model.Admin;
import com.academicportal.model.Teacher;

@Service
public class OTPService {
    
    private static final Logger logger = LoggerFactory.getLogger(OTPService.class);
    
    @Autowired
    private JavaMailSender mailSender;
    
    @Autowired
    private AdminRepository adminRepository;
    
    @Autowired
    private TeacherRepository teacherRepository;
    
    private final Map<String, String> otpStore = new ConcurrentHashMap<>();

    public boolean generateAndSendOTP(String email) {
        try {
            logger.debug("Starting OTP generation for email: {}", email);
            
            if (email == null || email.trim().isEmpty()) {
                logger.error("Email is null or empty");
                return false;
            }

            String trimmedEmail = email.trim();

            // Log the query we're about to execute
            logger.debug("Executing teacher query with emailid: {}", trimmedEmail);
            Teacher teacher = teacherRepository.findByEmailid(trimmedEmail);
            logger.debug("Teacher search result: {}", teacher != null ? "found" : "not found");

            // If teacher not found, try admin
            Admin admin = null;
            if (teacher == null) {
                logger.debug("Executing admin query with emailId: {}", trimmedEmail);
                admin = adminRepository.findByEmailId(trimmedEmail);
                logger.debug("Admin search result: {}", admin != null ? "found" : "not found");
            }

            if (teacher == null && admin == null) {
                logger.error("No user found with email: {} in either collection", trimmedEmail);
                return false;
            }

            // Generate OTP and store it
            String otp = generateOTP();
            otpStore.put(trimmedEmail, otp);
            logger.debug("Generated and stored OTP for email: {}", trimmedEmail);

            // Send email
            try {
                SimpleMailMessage message = new SimpleMailMessage();
                message.setFrom("richas0220@gmail.com");
                message.setTo(trimmedEmail);
                message.setSubject("Your OTP for Academic Portal");
                message.setText("Your OTP is: " + otp + "\nValid for 5 minutes.");
                
                mailSender.send(message);
                String userType = teacher != null ? "TEACHER" : "ADMIN";
                logger.info("OTP sent successfully to {} ({})", trimmedEmail, userType);
                return true;
            } catch (Exception e) {
                logger.error("Failed to send email: {}", e.getMessage());
                otpStore.remove(trimmedEmail); // Clean up stored OTP if email fails
                throw e;
            }

        } catch (Exception e) {
            logger.error("Error in generateAndSendOTP: {}", e.getMessage(), e);
            return false;
        }
    }

    private boolean sendOTP(String email, String userType) {
        try {
            String otp = generateOTP();
            otpStore.put(email, otp);
            
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("richas0220@gmail.com");
            message.setTo(email);
            message.setSubject("Your OTP for Academic Portal");
            message.setText("Your OTP is: " + otp + "\nValid for 5 minutes.");
            
            mailSender.send(message);
            logger.info("OTP sent successfully to {} ({})", email, userType);
            return true;
        } catch (Exception e) {
            logger.error("Failed to send OTP: ", e);
            return false;
        }
    }
    
    private String generateOTP() {
        SecureRandom random = new SecureRandom();
        return String.format("%04d", random.nextInt(10000));
    }

    public Map<String, String> verifyOTP(String email, String otp) {
        Map<String, String> response = new HashMap<>();
        String trimmedEmail = email.trim(); // <-- Add this

        try {
            logger.debug("Verifying OTP - Email: {}, Received OTP: {}", trimmedEmail, otp);

            // Get stored OTP
            String storedOTP = otpStore.get(trimmedEmail); // <-- Use trimmedEmail
            logger.debug("Stored OTP for {}: {}", trimmedEmail, storedOTP);

            if (storedOTP == null) {
                logger.error("No OTP found for email: {}", trimmedEmail);
                response.put("error", "No OTP found for this email");
                return response;
            }

            // Compare OTPs (trim and compare)
            if (!storedOTP.trim().equals(otp.trim())) {
                logger.error("Invalid OTP. Expected: '{}', Received: '{}'", storedOTP, otp);
                response.put("error", "Invalid OTP");
                return response;
            }

            // Remove used OTP immediately after successful verification
            otpStore.remove(trimmedEmail); // <-- Use trimmedEmail
            logger.info("OTP verified successfully for: {}", trimmedEmail);

            // Determine user type
            Admin admin = adminRepository.findByEmailId(trimmedEmail);
            if (admin != null) {
                logger.info("Admin verified successfully: {}", trimmedEmail);
                response.put("status", "success");
                response.put("userType", "ADMIN");
                response.put("redirectUrl", "/admin-dashboard.html");
                return response;
            }

            Teacher teacher = teacherRepository.findByEmailid(trimmedEmail);
            if (teacher != null) {
                logger.info("Teacher verified successfully: {}", trimmedEmail);
                response.put("status", "success");
                response.put("userType", "TEACHER");
                response.put("redirectUrl", "/teacher-dashboard.html");
                return response;
            }

            logger.error("User not found after successful OTP verification: {}", trimmedEmail);
            response.put("error", "User not found");
            return response;

        } catch (Exception e) {
            logger.error("Error in OTP verification: {}", e.getMessage());
            response.put("error", "Verification failed");
        }
        return response;
    }
}