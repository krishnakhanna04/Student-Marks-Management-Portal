package com.academicportal.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.academicportal.model.Teacher;
import com.academicportal.model.ClassRoom;
import com.academicportal.repository.TeacherRepository;
import com.academicportal.repository.ClassRoomRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

@Service
public class TeacherService {
    private static final Logger logger = LoggerFactory.getLogger(TeacherService.class);
    
    @Autowired
    private TeacherRepository teacherRepository;
    
    @Autowired
    private ClassRoomRepository classRoomRepository;
    
    @Autowired
    private MongoTemplate mongoTemplate;

    public Teacher getTeacherByEmail(String emailId) {
        logger.info("Finding teacher by email: {}", emailId);
        try {
            // First verify if MongoDB is accessible
            if (!mongoTemplate.collectionExists("teachers")) {
                logger.error("Teachers collection does not exist!");
                return null;
            }

            // Try direct MongoDB query with case-insensitive search
            Query query = new Query(Criteria.where("emailid").regex("^" + emailId + "$", "i"));
            logger.info("Executing query: {} in teachers collection", query);
            
            Teacher teacher = mongoTemplate.findOne(query, Teacher.class, "teachers");
            if (teacher != null) {
                logger.info("Found teacher: {} with ID: {}", teacher.getEmailid(), teacher.getTeacherId());
                return teacher;
            } else {
                // Try exact match as fallback
                query = new Query(Criteria.where("emailid").is(emailId));
                teacher = mongoTemplate.findOne(query, Teacher.class, "teachers");
                if (teacher != null) {
                    logger.info("Found teacher with exact match: {}", teacher.getEmailid());
                    return teacher;
                }
                logger.error("No teacher found with email: {}", emailId);
                return null;
            }
        } catch (Exception e) {
            logger.error("Database error: {}", e.getMessage(), e);
            return null;
        }
    }

    public List<ClassRoom> getTeacherClasses(String teacherId) {
        logger.info("Finding classes for teacher ID: {}", teacherId);
        
        // Update query to match actual document structure
        Query query = new Query(Criteria.where("subjectTeachers.teacher.teacherId").is(teacherId));
        List<ClassRoom> classes = mongoTemplate.find(query, ClassRoom.class, "classes");
        
        logger.info("Found {} classes for teacher ID: {}", classes.size(), teacherId);
        return classes;
    }

    public ClassRoom getClassRoomById(String classId) {
        return classRoomRepository.findById(classId).orElse(null);
    }
}