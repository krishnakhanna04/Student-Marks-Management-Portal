package com.academicportal.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.List;

@Document(collection = "marksheets")
public class Marksheet {
    @Id
    private String id;
    private String marksheetName;
    private String classId;
    private String subjectId;
    private int totalMarks;
    private int totalQuestions;
    private List<StudentMark> students;

    // Getters and setters
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getMarksheetName() {
        return marksheetName;
    }
    public void setMarksheetName(String marksheetName) {
        this.marksheetName = marksheetName;
    }
    public String getClassId() {
        return classId;
    }
    public void setClassId(String classId) {
        this.classId = classId;
    }
    public String getSubjectId() {
        return subjectId;
    }
    public void setSubjectId(String subjectId) {
        this.subjectId = subjectId;
    }
    public int getTotalMarks() {
        return totalMarks;
    }
    public void setTotalMarks(int totalMarks) {
        this.totalMarks = totalMarks;
    }
    public int getTotalQuestions() {
        return totalQuestions;
    }
    public void setTotalQuestions(int totalQuestions) {
        this.totalQuestions = totalQuestions;
    }
    public List<StudentMark> getStudents() {
        return students;
    }
    public void setStudents(List<StudentMark> students) {
        this.students = students;
    }

    public static class StudentMark {
        private String studentId;
        private List<Integer> questions;
        private int total;

        // Getters and setters
        public String getStudentId() {
            return studentId;
        }
        public void setStudentId(String studentId) {
            this.studentId = studentId;
        }
        public List<Integer> getQuestions() {
            return questions;
        }
        public void setQuestions(List<Integer> questions) {
            this.questions = questions;
        }
        public int getTotal() {
            return total;
        }
        public void setTotal(int total) {
            this.total = total;
        }
    }
}
