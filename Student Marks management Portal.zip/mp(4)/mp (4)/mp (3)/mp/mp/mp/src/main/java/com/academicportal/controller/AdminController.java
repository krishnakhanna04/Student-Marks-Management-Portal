package com.academicportal.controller;

import com.academicportal.repository.TeacherRepository;
import com.academicportal.repository.CourseRepository;
import com.academicportal.model.*;
import com.academicportal.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController {
    @Autowired
    private AdminService adminService;

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private TeacherRepository teacherRepository;

    @Autowired
    private CourseRepository courseRepository;

    // Keep this endpoint
    @GetMapping("/admin/{emailId}")
    public ResponseEntity<Admin> getAdminByEmail(@PathVariable String emailId) {
        Admin admin = adminService.getAdminByEmail(emailId);
        if (admin == null) {
            System.out.println("Admin not found for emailId: " + emailId);
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(admin);
    }

    // Teacher endpoints
    @GetMapping("/teachers")
    public List<Teacher> getAllTeachers() {
        return teacherRepository.findAll();
    }

    @GetMapping("/teachers/{id}")
    public ResponseEntity<Teacher> getTeacherById(@PathVariable String id) {
        Teacher teacher = adminService.getTeacherById(id);
        return teacher != null ? ResponseEntity.ok(teacher) : ResponseEntity.notFound().build();
    }

    @PostMapping("/teachers")
    public Teacher createTeacher(@RequestBody Teacher teacher) {
        return adminService.createTeacher(teacher);
    }

    @PutMapping("/teachers/{id}")
    public ResponseEntity<Teacher> updateTeacher(@PathVariable String id, @RequestBody Teacher teacher) {
        teacher.setTeacherId(id);
        return ResponseEntity.ok(adminService.updateTeacher(teacher));
    }

    @DeleteMapping("/teachers/{id}")
    public ResponseEntity<?> deleteTeacher(@PathVariable String id) {
        Query findQuery = new Query(Criteria.where("teacherId").is(id));
        Teacher teacher = mongoTemplate.findOne(findQuery, Teacher.class);
        if (teacher != null) {
            Query deleteQuery = new Query(Criteria.where("_id").is(teacher.getId()));
            mongoTemplate.remove(deleteQuery, Teacher.class);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Student endpoints
    @GetMapping("/students")
    public List<Student> getAllStudents() {
        return adminService.getAllStudents();
    }

    @GetMapping("/students/{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable String id) {
        Student student = adminService.getStudentById(id);
        return student != null ? ResponseEntity.ok(student) : ResponseEntity.notFound().build();
    }

    @PostMapping("/students")
    public Student createStudent(@RequestBody Student student) {
        return adminService.createStudent(student);
    }

    @PutMapping("/students/{id}")
    public ResponseEntity<Student> updateStudent(@PathVariable String id, @RequestBody Student student) {
        student.setStudentId(id);
        return ResponseEntity.ok(adminService.updateStudent(student));
    }

    @DeleteMapping("/students/{id}")
    public ResponseEntity<?> deleteStudent(@PathVariable String id) {
        adminService.deleteStudent(id);
        return ResponseEntity.ok().build();
    }

    // Course endpoints
    @GetMapping("/courses")
    public List<Course> getAllCourses() {
        return adminService.getAllCourses();
    }

    @GetMapping("/courses/{id}")
    public ResponseEntity<Course> getCourseById(@PathVariable String id) {
        Course course = adminService.getCourseById(id);
        return course != null ? ResponseEntity.ok(course) : ResponseEntity.notFound().build();
    }

    @PostMapping("/courses")
    public ResponseEntity<Course> addCourse(@RequestBody Course course) {
        Course savedCourse = adminService.createCourse(course);
        return ResponseEntity.ok(savedCourse);
    }

    @PutMapping("/courses/{courseId}")
    public ResponseEntity<?> updateCourse(@PathVariable String courseId, @RequestBody Course course) {
        course.setCourseId(courseId);
        return ResponseEntity.ok(adminService.updateCourse(course));
    }

    @DeleteMapping("/courses/{id}")
    public ResponseEntity<?> deleteCourse(@PathVariable String id) {
        courseRepository.deleteById(id);
        return ResponseEntity.ok().build();
    }

    // Subject endpoints
    @GetMapping("/subjects")
    public List<Subject> getAllSubjects() {
        return adminService.getAllSubjects();
    }

    @GetMapping("/subjects/{id}")
    public ResponseEntity<Subject> getSubjectById(@PathVariable String id) {
        Subject subject = adminService.getSubjectById(id);
        return subject != null ? ResponseEntity.ok(subject) : ResponseEntity.notFound().build();
    }

    @PostMapping("/subjects")
    public Subject createSubject(@RequestBody Subject subject) {
        return adminService.createSubject(subject);
    }

    @PutMapping("/subjects/{id}")
    public ResponseEntity<Subject> updateSubject(@PathVariable String id, @RequestBody Subject subject) {
        subject.setSubjectId(id);
        return ResponseEntity.ok(adminService.updateSubject(subject));
    }

    @DeleteMapping("/subjects/{id}")
    public ResponseEntity<?> deleteSubject(@PathVariable String id) {
        adminService.deleteSubject(id);
        return ResponseEntity.ok().build();
    }

    // Class endpoints
    @GetMapping("/classes")
    public List<ClassRoom> getAllClasses() {
        return adminService.getAllClasses();
    }

    @GetMapping("/classes/{id}")
    public ResponseEntity<ClassRoom> getClassById(@PathVariable String id) {
        ClassRoom classObj = adminService.getClassById(id);
        return classObj != null ? ResponseEntity.ok(classObj) : ResponseEntity.notFound().build();
    }

    @PostMapping("/classes")
    public ClassRoom createClass(@RequestBody ClassRoom classObj) {
        return adminService.createClass(classObj);
    }

    @PutMapping("/classes/{id}")
    public ResponseEntity<ClassRoom> updateClass(@PathVariable String id, @RequestBody ClassRoom classObj) {
        classObj.setClassId(id);
        return ResponseEntity.ok(adminService.updateClass(classObj));
    }

    @DeleteMapping("/classes/{id}")
    public ResponseEntity<?> deleteClass(@PathVariable String id) {
        adminService.deleteClass(id);
        return ResponseEntity.ok().build();
    }

    // -------------------------
    // NEW: Generate Student PDF Report
    // -------------------------
    @GetMapping("/report/{studentId}")
    public ResponseEntity<?> generateStudentReport(@PathVariable String studentId) {
        try {
            byte[] pdfBytes = adminService.generateStudentReport(studentId);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=marksheet.pdf")
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(pdfBytes);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error generating report");
        }
    }
}
