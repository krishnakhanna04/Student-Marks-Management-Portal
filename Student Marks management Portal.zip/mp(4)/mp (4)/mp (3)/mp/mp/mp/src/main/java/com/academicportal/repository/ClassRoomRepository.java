package com.academicportal.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.academicportal.model.ClassRoom;

public interface ClassRoomRepository extends MongoRepository<ClassRoom, String> {
    @Query("{ 'subjectTeachers': { $elemMatch: { 'teacher.teacherId': ?0 } } }")
    List<ClassRoom> findClassesByTeacherId(String teacherId);

    ClassRoom findByClassId(String classId);
}