package com.academicportal.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "classes")
public class ClassRoom {
    @Id
    private String id;
    private String courseId;
    private String courseName;
    private List<SubjectTeacher> subjectTeachers;
    private List<Student> students;
    private String classId;

    // Complete getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getCourseId() { return courseId; }
    public void setCourseId(String courseId) { this.courseId = courseId; }
    
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }
    
    public List<SubjectTeacher> getSubjectTeachers() { return subjectTeachers; }
    public void setSubjectTeachers(List<SubjectTeacher> subjectTeachers) { 
        this.subjectTeachers = subjectTeachers; 
    }
    
    public List<Student> getStudents() {
        return this.students;
    }
    public void setStudents(List<Student> students) { this.students = students; }
    
    public String getClassId() { return classId; }
    public void setClassId(String classId) { this.classId = classId; }
}