package com.academicportal.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import com.fasterxml.jackson.annotation.JsonProperty;

@Document(collection = "teachers")  // Changed from "teacher" to "teachers" to match MongoDB collection name
public class Teacher {
    @Id
    @Field("_id")
    @JsonProperty("_id")
    private String id;
    private String firstName;
    private String lastName;
    private String emailid; // Note: matches the MongoDB field name
    private String address;
    private String phoneNo;
    private String hiredate;
    private String teacherId;

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getEmailid() { return emailid; }
    public void setEmailid(String emailid) { this.emailid = emailid; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getPhoneNo() { return phoneNo; }
    public void setPhoneNo(String phoneNo) { this.phoneNo = phoneNo; }

    public String getHiredate() { return hiredate; }
    public void setHiredate(String hiredate) { this.hiredate = hiredate; }

    public String getTeacherId() { return teacherId; }
    public void setTeacherId(String teacherId) { this.teacherId = teacherId; }
}