package com.academicportal.service;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.academicportal.model.Marksheet;
import com.academicportal.repository.MarksheetRepository;
import com.academicportal.repository.SubjectRepository;
import com.academicportal.model.Subject;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.academicportal.model.Admin;
import com.academicportal.repository.AdminRepository;
import com.academicportal.model.ClassRoom;
import com.academicportal.model.Course;
import com.academicportal.model.Student;
import com.academicportal.model.Teacher;
import com.academicportal.repository.ClassRoomRepository;
import com.academicportal.repository.CourseRepository;
import com.academicportal.repository.StudentRepository;
import com.academicportal.repository.TeacherRepository;

@Service
public class AdminService {
    @Autowired
    private AdminRepository adminRepository;
    
    public Admin getAdminByEmail(String emailId) {
        return adminRepository.findByEmailId(emailId);
    }

    @Autowired
    private TeacherRepository teacherRepository;
    @Autowired
    private StudentRepository studentRepository;
    @Autowired
    private CourseRepository courseRepository;
    @Autowired
    private SubjectRepository subjectRepository;
    @Autowired
    private ClassRoomRepository classRoomRepository;

    @Autowired
    private MarksheetRepository marksheetRepository;

    // Teacher CRUD operations
    public List<Teacher> getAllTeachers() {
        return teacherRepository.findAll();
    }

    public Teacher getTeacherById(String id) {
        return teacherRepository.findById(id).orElse(null);
    }

    public Teacher createTeacher(Teacher teacher) {
        return teacherRepository.save(teacher);
    }

    public Teacher updateTeacher(Teacher teacher) {
        return teacherRepository.save(teacher);
    }

    public void deleteTeacher(String id) {
        teacherRepository.deleteById(id);
    }

    // Student CRUD operations
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Student getStudentById(String id) {
        return studentRepository.findById(id).orElse(null);
    }

    public Student createStudent(Student student) {
        return studentRepository.save(student);
    }

    public Student updateStudent(Student student) {
        return studentRepository.save(student);
    }

    public void deleteStudent(String id) {
        studentRepository.deleteById(id);
    }

    // Course CRUD operations
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    public Course getCourseById(String id) {
        return courseRepository.findById(id).orElse(null);
    }

    public Course createCourse(Course course) {
        return courseRepository.save(course);
    }

    public Course updateCourse(Course course) {
        return courseRepository.save(course);
    }

    public void deleteCourse(String id) {
        courseRepository.deleteById(id);
    }

    // Subject CRUD operations
    public List<Subject> getAllSubjects() {
        return subjectRepository.findAll();
    }

    public Subject getSubjectById(String id) {
        return subjectRepository.findById(id).orElse(null);
    }

    public Subject createSubject(Subject subject) {
        return subjectRepository.save(subject);
    }

    public Subject updateSubject(Subject subject) {
        return subjectRepository.save(subject);
    }

    public void deleteSubject(String id) {
        subjectRepository.deleteById(id);
    }

    // Class CRUD operations
    public List<ClassRoom> getAllClasses() {
        return classRoomRepository.findAll();
    }

    public ClassRoom getClassById(String id) {
        return classRoomRepository.findById(id).orElse(null);
    }

    public ClassRoom createClass(ClassRoom classRoom) {
        return classRoomRepository.save(classRoom);
    }

    public ClassRoom updateClass(ClassRoom classRoom) {
        return classRoomRepository.save(classRoom);
    }

    public void deleteClass(String id) {
        classRoomRepository.deleteById(id);
    }

    // Fetch students by course code
    public List<Student> getStudentsByCourseCode(String courseCode) {
        System.out.println("Searching for students with courseCode: " + courseCode);
        Course course = courseRepository.findByCoursecode(courseCode);
        if (course != null) {
            List<Student> students = studentRepository.findByCourseCode(course.getCoursecode());
            System.out.println("Found " + students.size() + " students for course: " + course.getCourseName());
            return students;
        }
        return new ArrayList<>();
    }

    // -------------------------------
    // NEW: Generate Student Report in PDF
    // -------------------------------
    public byte[] generateStudentReport(String studentId) throws Exception {
        // Fetch student
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));

        // Fetch marks
        List<Marksheet> marksheets = marksheetRepository.findByStudentId(studentId);
        if (marksheets.isEmpty()) {
            throw new RuntimeException("Marks not entered yet for this student");
        }

        // Create PDF
        Document document = new Document();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PdfWriter.getInstance(document, baos);
        document.open();

        // Title
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
        Paragraph title = new Paragraph("Student Marksheet Report", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        document.add(title);
        document.add(new Paragraph(" "));

        // Student details
        document.add(new Paragraph("Name: " + student.getName()));
        document.add(new Paragraph("Roll No: " + student.getRollNo()));
        document.add(new Paragraph("Course: " + student.getCourseCode()));
        document.add(new Paragraph(" "));

        // Table
        PdfPTable table = new PdfPTable(3);
        table.addCell("Subject");
        table.addCell("Marks");
        table.addCell("Grade");

        for (Marksheet m : marksheets) {
            Subject subject = subjectRepository.findById(m.getSubjectId()).orElse(null);
            table.addCell(subject != null ? subject.getName() : "Unknown");
            table.addCell(String.valueOf(m.getMarks()));
            table.addCell(m.getGrade());
        }

        document.add(table);
        document.close();

        return baos.toByteArray();
    }
}
