package com.academicportal.repository;

import com.academicportal.model.Marksheet;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface MarksheetRepository extends MongoRepository<Marksheet, String> {
    // You can add custom queries if needed
}
